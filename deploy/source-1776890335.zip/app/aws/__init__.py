"""AWS package."""
